#include <stdio.h>
#include <conio.h>
#include <math.h>
#include <bios.h>
#include <graphics.h>
#include <stdlib.h>

int outtextxyCHN(int x, int y, char* s, char* pathHZK);
int putCHNChar(int x, int y, char* s, int color, FILE* fp);

int main(void)
{
	char ss[50] = "好好好haohaohao";
	int gdriver = VGA, gmode = VGAHI;
 
	initgraph(&gdriver, &gmode, "C:\\BORLANDC\\BGI");

	outtextxyCHN(10, 100, ss, "c:\\hzk16");

	getch();
	closegraph();
}

int outtextxyCHN(int x, int y, char *s, char *pathHZK)
{
	char* p;
	char ss[2] = { 0 };
	FILE* fp;
	fp = fopen(pathHZK, "rb");
	if (!fp) return -1;

	p = s;
	while (*p != 0)
	{
		if ((unsigned char)(*p) > 0x80)
		{
			putCHNChar(x, y, p,RED, fp);
			p += 2;
			x += 16;
		}
		else
		{
			ss[0] = *p;
			outtextxy(x, y, ss);
			p += 1;
			x += 8;
		}
	}
	fclose(fp);

}

int putCHNChar(int x, int y, char* s, int color, FILE *fp)
{
	unsigned char msk[8] = {0x80, 0x40, 0x20, 0x10, 0x08, 0x04, 0x02, 0x01};
	int qh, wh;
	unsigned long offset;
	int i, k, j;
	unsigned char code[32],ch;

	qh = s[0] - 160;   wh = s[1] - 160;
	offset = ((qh - 1) * 94 + wh - 1) * 32L;
	fseek(fp,offset,0);
	fread(code, 1, 32, fp);

	for (i = 0; i < 16; i++)
	{
		for (j = 0; j < 2; j++)
		{
			ch = code[i * 2 + j];
			for (k = 0; k < 8; j++)
			{
				if (ch & msk[k])
				{
					putpixel(x + j * 8 + k, y + i, color);

				}
			}
		}
	}
	return 0;
}